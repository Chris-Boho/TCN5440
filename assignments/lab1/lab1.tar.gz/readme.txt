I have done this assignment completely on my own. 
I have not copied it, nor have I given my solution to anyone else. 
I understand that if I am involved in plagiarism or cheating 
I will receive the penalty specified in the FIU regulations.