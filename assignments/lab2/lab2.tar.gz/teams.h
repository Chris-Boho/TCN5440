#include <stdio.h>
#include <stdlib.h>

struct Team
{
    char team_name[15];
    int handicap;
};

typedef struct Team Team;